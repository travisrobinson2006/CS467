#Travis Robinson
#Centaurus
#CS467
#Oregon State University

#this config file is simply for storing email addresses for error reporting
SENDING_EMAIL = "travisrobinson2006@gmail.com"

RECEIVING_EMAILS = ["robitrav@oregonstate.edu"]

SECRET_CODE = "axaqbqrprggfbvbz"