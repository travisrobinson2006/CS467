BASE_FILE_NAME = "tweets"
UNCLEANED_TWEETS_DIRECTORY = "unclean_tweets"